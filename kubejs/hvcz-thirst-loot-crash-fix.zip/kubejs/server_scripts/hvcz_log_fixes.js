// Repairs for latest.log from 2026-10-11, Minecraft 1.20.1 / KubeJS 6 / Forge.
// Data overrides run BEFORE JSON/recipe deserialization. event.remove() is too late
// for malformed JSON and missing-item errors during the initial recipe scan.
ServerEvents.highPriorityData(event => {
  var hvczResourcePacks = Java.loadClass('net.minecraftforge.resource.ResourcePackLoader')
  var hvczJavaString = Java.loadClass('java.lang.String')

  // Read the installed mod's own table so its rolls, weights and valid entries
  // survive. This intentionally touches only the resources named in the log.
  function readModJson(mod, resource) {
    if (!Platform.isLoaded(mod)) return null
    var stream = null
    try {
      var parts = resource.split(':')
      var pack = hvczResourcePacks.getPackFor(mod)
      if (!pack.isPresent()) return null
      // JsonIO's Path wrapper accepts only the game-directory filesystem, not
      // Forge's union/jar filesystem. Open the installed mod's resource through
      // Forge's resource-pack API instead. Its methods take strings, avoiding
      // forbidden Files/FML imports and the script's Path conversion entirely.
      // ModernFix indexes individual path components. Passing a slash-containing
      // third argument works in plain Forge but silently misses its cache.
      var resourcePath = ('data/' + parts[0] + '/' + parts[1] + '.json').split('/')
      var resourceStream = pack.get().getRootResource(resourcePath)
      if (resourceStream === null) return null
      stream = resourceStream.get()
      return JSON.parse(String(new hvczJavaString(stream.readAllBytes(), 'UTF-8')))
    } catch (error) {
      console.warn('[HVCZ fixes] Cannot read ' + resource + ': ' + error)
      return null
    } finally {
      if (stream !== null) {
        try { stream.close() }
        catch (closeError) { console.warn('[HVCZ fixes] Cannot close ' + resource + ': ' + closeError) }
      }
    }
  }

  // Forge evaluates the false condition before trying to deserialize the recipe.
  function disableRecipe(id) {
    event.addJson(id.replace(':', ':recipes/'), {
      type: 'minecraft:crafting_shapeless',
      conditions: [{ type: 'forge:false' }]
    })
  }

  // These malformed cross-mod resources have no usable ingredients in this pack.
  // Do not override them if the corresponding optional mod is added later.
  if (!Platform.isLoaded('create_dd')) {
    disableRecipe('create_dd:crafting/tin_ingot_from_decompacting')
    disableRecipe('create_dd:crafting/tin_nugget_from_decompacting')
    // These additional resources deserialize to empty outputs in latest(2).log.
    ;['steel_block_from_compacting', 'steel_ingot_from_compacting',
      'steel_nugget_from_decompacting', 'steel_ingot_from_decompacting',
      'tin_ingot_from_compacting', 'tin_block_from_compacting'].forEach(recipe => {
      disableRecipe('create_dd:crafting/' + recipe)
    })
  }
  if (!Platform.isLoaded('immersiveengineering')) {
    ;['aluminum', 'copper', 'lead', 'steel'].forEach(metal => {
      disableRecipe('create:cutting/compat/immersiveengineering/wire_' + metal)
    })
  }

  // Stale compatibility recipes: leave them intact when their input exists.
  ;['steel', 'bronze', 'tin'].forEach(metal => {
    ;['ceramic', 'metal'].forEach(mold => {
      var input = 'molten_metals:molten_' + metal +
        (mold === 'ceramic' ? '_ceramic_ingot_mold' : '_ingot_mold')
      if (!Item.exists(input)) {
        disableRecipe('create_ironworks:compat/molten_metals/splashing/' +
          metal + '_ingot_from_' + mold + '_mold')
      }
    })
  })
  ;[
    ['create_ironworks:compat/dreams_and_desires/crushing_coal_piece', 'create_dd:coal_piece'],
    ['create_ironworks:compat/dreams_and_desires/raw_tin_exchange', 'create_dd:raw_tin'],
    ['createcasing:crafting/chain_drive/creative_from_zinc', 'create:creative_casing']
  ].forEach(fix => {
    if (!Item.exists(fix[1])) disableRecipe(fix[0])
  })

  // The shipped TConstruct-namespace overrides use absent steel items/empty keys.
  // Retain the intended 9:1 conversions using this pack's preferred TFMG steel.
  if (Item.exists('tfmg:steel_ingot') && Item.exists('tfmg:steel_nugget') &&
      Item.exists('tfmg:steel_block')) {
    event.addJson('tconstruct:recipes/common/materials/steel_nugget_from_ingot', {
      type: 'minecraft:crafting_shapeless',
      ingredients: [{ item: 'tfmg:steel_ingot' }],
      result: { item: 'tfmg:steel_nugget', count: 9 }
    })
    event.addJson('tconstruct:recipes/common/materials/steel_ingot_from_nuggets', {
      type: 'minecraft:crafting_shaped',
      pattern: ['NNN', 'NNN', 'NNN'],
      key: { N: { item: 'tfmg:steel_nugget' } },
      result: { item: 'tfmg:steel_ingot' }
    })
    event.addJson('tconstruct:recipes/common/materials/steel_ingot_from_block', {
      type: 'minecraft:crafting_shapeless',
      ingredients: [{ item: 'tfmg:steel_block' }],
      result: { item: 'tfmg:steel_ingot', count: 9 }
    })
    event.addJson('tconstruct:recipes/common/materials/steel_block_from_ingots', {
      type: 'minecraft:crafting_shaped',
      pattern: ['III', 'III', 'III'],
      key: { I: { item: 'tfmg:steel_ingot' } },
      result: { item: 'tfmg:steel_block' }
    })
  }

  // Alex's Delight retained an old AMFD namespace for its cooked moose rib.
  var rib = Item.exists('alexsdelight:cooked_loose_moose_rib')
    ? 'alexsdelight:cooked_loose_moose_rib' : 'alexsdelight:singular_cooked_moose_rib'
  if (Platform.isLoaded('alexsdelight') && !Item.exists('amfd:singular_cooked_moose_rib')) {
    if ([rib, 'farmersdelight:tomato', 'farmersdelight:onion',
         'farmersdelight:barbecue_stick'].every(id => Item.exists(id))) {
      event.addJson('alexsdelight:recipes/barbecue_on_a_stick', {
        type: 'minecraft:crafting_shapeless',
        group: 'barbecue_stick',
        ingredients: [
          { item: 'farmersdelight:tomato' }, { item: 'farmersdelight:onion' },
          { item: rib }, { item: 'minecraft:cooked_chicken' },
          { item: 'minecraft:stick' }, { item: 'minecraft:stick' }
        ],
        result: { item: 'farmersdelight:barbecue_stick', count: 2 }
      })
    } else {
      disableRecipe('alexsdelight:barbecue_on_a_stick')
      console.warn('[HVCZ fixes] Moose rib recipe disabled: replacement ingredients are missing')
    }
  }

  // Convert ONLY nonexistent item entries to empty entries. Keeping their weight
  // preserves the odds of the remaining loot instead of making it more common.
  function repairLootEntries(node) {
    if (Array.isArray(node)) return node.map(repairLootEntries)
    if (!node || typeof node !== 'object') return node
    if (node.type === 'minecraft:item' && !Item.exists(node.name)) {
      var empty = { type: 'minecraft:empty' }
      ;['weight', 'quality', 'conditions'].forEach(key => {
        if (node[key] !== undefined) empty[key] = node[key]
      })
      return empty
    }
    Object.keys(node).forEach(key => { node[key] = repairLootEntries(node[key]) })
    return node
  }

  var chestLootOverrides = 0
  if (Platform.isLoaded('thirst')) {
    ;['shipwreck_supply', 'simple_dungeon', 'bastion_other',
      'abandoned_mineshaft', 'nether_bridge'].forEach(chest => {
      ;['bc', 'fr'].forEach(compat => {
        var resource = 'thirst:loot_tables/chests/' + chest + '_' + compat
        var table = readModJson('thirst', resource)
        if (table) {
          event.addJson(resource, repairLootEntries(table))
          chestLootOverrides++
        }
      })
    })
  }
  var bank = 'lightmanscurrency:loot_tables/chest/village/idas_taiga_large_bank'
  var bankTable = readModJson('lightmanscurrency', bank)
  if (bankTable) {
    event.addJson(bank, repairLootEntries(bankTable))
    chestLootOverrides++
  }
  console.info('[HVCZ fixes] Prepared ' + chestLootOverrides + ' chest loot table overrides')

  // Thirst 1.4.0 calls getRandomItems() from inside a global loot modifier.
  // Forge retains the original queried table ID, so its condition matches again
  // and recursively reapplies the entire modifier chain until StackOverflowError.
  // Farmer's Delight uses getRandomItemsRaw() with a stack splitter instead.
  // Its codec has the same conditions/lootTable schema; retain all other data.
  if (Platform.isLoaded('thirst') && Platform.isLoaded('farmersdelight')) {
    var safeThirstModifiers = 0
    ;['shipwreck_supply', 'simple_dungeon', 'bastion_other',
      'abandoned_mineshaft', 'nether_bridge'].forEach(chest => {
      ;['', '_bc', '_fr'].forEach(suffix => {
        var resource = 'thirst:loot_modifiers/add_loot_' + chest + suffix
        var modifier = readModJson('thirst', resource)
        if (modifier && modifier.type === 'thirst:add_loot_table' &&
            typeof modifier.lootTable === 'string' && Array.isArray(modifier.conditions)) {
          modifier.type = 'farmersdelight:add_loot_table'
          event.addJson(resource, modifier)
          safeThirstModifiers++
        }
      })
    })
    console.info('[HVCZ fixes] Prepared ' + safeThirstModifiers + ' non-recursive Thirst loot modifiers')
    if (safeThirstModifiers !== 15) {
      console.warn('[HVCZ fixes] Expected 15 Thirst loot modifiers; review the installed mod resources')
    }
  }

  // Radar ships loot for blocks that are registered only with optional addons.
  if (Platform.isLoaded('create_radar')) {
    ;['plane_radar', 'identification_transponder', 'radar_guidance_block'].forEach(block => {
      if (!Item.exists('create_radar:' + block)) {
        event.addJson('create_radar:loot_tables/blocks/' + block, {
          type: 'minecraft:block', pools: []
        })
        if (block === 'plane_radar' || block === 'identification_transponder') {
          disableRecipe('create_radar:crafting/' + block)
        }
      }
    })
    if (!Item.exists('create_radar:incomplete_network_controller')) {
      disableRecipe('create_radar:sequenced_assembly/network_filterer')
    }
  }

  // Only the reported Saro recipe; inspect its shipped result instead of
  // guessing a replacement ID or registering a nonfunctional placeholder.
  var trafficRecipe = readModJson('saros_road_signs_mod',
    'saros_road_signs_mod:recipes/traffic_light_control_boxrez')
  if (trafficRecipe && trafficRecipe.result && trafficRecipe.result.item &&
      (trafficRecipe.result.item === 'minecraft:air' || !Item.exists(trafficRecipe.result.item))) {
    disableRecipe('saros_road_signs_mod:traffic_light_control_boxrez')
  }
})

ServerEvents.tags('item', event => {
  // Remove the four obsolete entries only; keep traffic lights from other mods.
  ;[1, 2, 3, 5].forEach(number => {
    var id = 'saros_road_signs_mod:trafficlight_' + number
    if (!Item.exists(id)) event.remove('forge:traffic_lights', id)
  })
  if (Item.exists('tfmg:sulfuric_acid_bucket')) {
    event.add('forge:buckets/sulfuric_acid', 'tfmg:sulfuric_acid_bucket')
  }
})
